import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:myapp/login_form.dart';

class CreateAnAccount extends StatefulWidget {
  const CreateAnAccount({super.key});

  @override
  State<CreateAnAccount> createState() => _CreateAnAccountState();
}

class _CreateAnAccountState extends State<CreateAnAccount> {
  bool isChecked = false;
  String? nameError, emailError, passwordError;
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Create Your Account'), centerTitle: true),
      bottomSheet: InkWell(
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => LoginForm()),
          );
        },
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(color: Colors.transparent),
          child: const Text(
            "Already have an account? Login",
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 16),
          ),
        ),
      ),
      body: SafeArea(
        child: Container(
          decoration: BoxDecoration(
            image: DecorationImage(
              image: NetworkImage('https://tinyurl.com/2x48ataa'),
              fit: BoxFit.cover,
            ),
          ),
          child: Padding(
            padding: const EdgeInsets.all(18.0),
            child: Container(
              margin: EdgeInsets.all(18),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Sign In',
                    style: TextStyle(
                      fontSize: 21,
                      fontWeight: FontWeight.w800,
                      color: Color(0xFF171A3B),
                    ),
                  ),
                  SizedBox(height: 21),
                  Column(
                    children: [
                      TextField(
                        controller: _nameController,
                        decoration: InputDecoration(
                          hintText: "Name",
                          filled: true,
                          fillColor: Color(0xFFF7F7F7),
                          prefixIcon: Icon(Icons.person),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12),
                            borderSide: BorderSide.none,
                          ),
                          errorText: nameError,
                        ),
                      ),
                      SizedBox(height: 09),
                      TextField(
                        decoration: InputDecoration(
                          hintText: "Email",
                          filled: true,
                          fillColor: Color(0xFFF7F7F7),
                          prefixIcon: Icon(Icons.email),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12),
                            borderSide: BorderSide.none,
                          ),
                          errorText: emailError,
                        ),
                      ),

                      SizedBox(height: 09),
                      TextField(
                        decoration: InputDecoration(
                          hintText: "Password",
                          filled: true,
                          fillColor: Color(0xFFF7F7F7),
                          prefixIcon: Icon(Icons.password),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12),
                            borderSide: BorderSide.none,
                          ),
                          errorText: passwordError,
                        ),
                      ),
                      SizedBox(height: 3),
                      Row(
                        children: [
                          Checkbox(
                            activeColor: Color(0xFF171A3B),
                            value: isChecked,
                            onChanged: (value) {
                              setState(() {
                                if (isChecked == false) {
                                  isChecked = true;
                                } else if (isChecked == true) {
                                  isChecked = false;
                                }
                              });
                            },
                          ),
                          Text(
                            'I agree with Terms & Conditions',
                            style: TextStyle(color: Color(0xFF171A3B)),
                          ),
                        ],
                      ),

                      Container(
                        width: MediaQuery.sizeOf(context).width * 1,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [
                              Color.fromARGB(240, 23, 26, 59),
                              Color(0xFF4B1D5B),
                            ],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          ),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: ElevatedButton(
                          onPressed: () {
                            setState(() {
                              nameError = _nameController.text.isEmpty
                                  ? 'Name is required'
                                  : null;
                              emailError = _emailController.text.isEmpty
                                  ? 'Email is required'
                                  : null;
                              passwordError = _passwordController.text.isEmpty
                                  ? 'Password is required'
                                  : null;
                            });
                            if (nameError == null &&
                                emailError == null &&
                                passwordError == null) {
                              // Proceed to create account
                              print('All fields valid');
                            }
                          },
                          style: ElevatedButton.styleFrom(
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                            backgroundColor: Colors.transparent,
                          ),
                          child: Text(
                            'Create An Account',
                            style: TextStyle(
                              fontWeight: FontWeight.w700,
                              color: Colors.white,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
