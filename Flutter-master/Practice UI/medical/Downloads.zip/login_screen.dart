import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Login Screen',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        textTheme: GoogleFonts.josefinSansTextTheme(),
      ),
      home: const MyHomePage(title: 'Medical Login Screen'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Category')),
      drawer: Drawer(
        child: ListView(
          children: [
            Container(
              height: 90,
              width: double.infinity,
              child: Align(
                alignment: Alignment.center,
                child: DrawerHeader(
                  curve: Curves.bounceIn,
                  child: SizedBox(
                    child: Image.network(
                      'https://tinyurl.com/3j9befdn',
                      fit: BoxFit.contain,
                    ),
                  ),
                ),
              ),
            ),
            SizedBox(height: 30),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                TextButton.icon(
                  onPressed: () {},
                  label: Text('Home'),
                  icon: Icon(Icons.home),
                ),
                TextButton.icon(
                  onPressed: () {},
                  label: Text('Product'),
                  icon: Icon(Icons.local_pharmacy),
                ),
                TextButton.icon(
                  onPressed: () {},
                  label: Text('Checkout'),
                  icon: Icon(Icons.shopping_bag),
                ),
              ],
            ),

            Row(
              children: [
                TextButton.icon(
                  onPressed: () {},
                  label: Text('Sign In'),
                  icon: Icon(Icons.add_home),
                ),
                TextButton.icon(
                  onPressed: () {},
                  label: Text('Create An Account'),
                  icon: Icon(Icons.person),
                ),
              ],
            ),
          ],
        ),
      ),
      body: Container(
        child: Column(
          children: [
            // 1st Container
            Container(
              height: MediaQuery.sizeOf(context).height * 0.45,
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: NetworkImage('https://tinyurl.com/yppyj2rb'),
                  fit: BoxFit.cover,
                ),
                borderRadius: BorderRadius.only(
                  bottomLeft: Radius.circular(60),
                ),
              ),
            ),

            // End 1st Container

            //2nd Container
            Container(
              width: MediaQuery.sizeOf(context).width * 0.9,
              child: Column(
                children: [
                  // Heading
                  Column(
                    children: [
                      Text(
                        'Login to Account',
                        style: TextStyle(
                          fontSize: 26,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text(
                        'Welcome back,please login to continue',
                        style: TextStyle(
                          fontSize: 18,
                          color: Colors.blueGrey,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                  // End Heading

                  // Input Fields
                  Container(
                    margin: EdgeInsets.only(top: 20),

                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // Username / Email
                        TextField(
                          decoration: InputDecoration(
                            label: Text('Username / Phone Number'),
                            prefixIcon: Icon(Icons.person),
                            border: OutlineInputBorder(
                              borderSide: BorderSide(
                                width: 2,
                                color: Colors.blueGrey,
                              ),
                              borderRadius: BorderRadius.circular(12),
                            ),
                          ),
                        ),

                        SizedBox(height: 6),
                        // Password
                        TextField(
                          obscureText: true,
                          decoration: InputDecoration(
                            label: Text('Password'),
                            prefixIcon: Icon(Icons.lock),
                            border: OutlineInputBorder(
                              borderSide: BorderSide(
                                width: 2,
                                color: Colors.blueGrey,
                              ),
                              borderRadius: BorderRadius.circular(12),
                            ),
                          ),
                        ),

                        Align(
                          alignment: Alignment.centerLeft,

                          child: CheckboxListTile(
                            value: true,
                            onChanged: (_) {},

                            title: Text('Remember Me'),
                            controlAffinity: ListTileControlAffinity.leading,
                            contentPadding: EdgeInsets.zero,
                          ),
                        ),
                      ],
                    ),
                  ),

                  // End Input Fields

                  // Login Button
                  Container(
                    width: MediaQuery.sizeOf(context).width * 0.9,
                    decoration: BoxDecoration(
                      color: Colors.blue,
                      borderRadius: BorderRadius.circular(30),
                    ),
                    child: Column(
                      children: [
                        // Login Button
                        Container(
                          width: double.infinity,
                          height: MediaQuery.sizeOf(context).height * 0.07,
                          child: Expanded(
                            child: ElevatedButton.icon(
                              onPressed: () {},
                              label: Text(
                                'Login',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 18,
                                ),
                              ),
                              icon: Icon(Icons.login),
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.blue,
                                iconColor: Colors.white,
                              ),
                            ),
                          ),
                        ),

                        // End Login Button
                      ],
                    ),
                  ),

                  // End Login Button
                  SizedBox(height: 9),

                  // Signup Button
                  Container(
                    width: MediaQuery.sizeOf(context).width * 0.9,
                    decoration: BoxDecoration(
                      color: Colors.black,
                      borderRadius: BorderRadius.circular(30),
                    ),
                    child: Column(
                      children: [
                        Container(
                          width: double.infinity,
                          height: MediaQuery.sizeOf(context).height * 0.07,
                          child: Expanded(
                            child: ElevatedButton.icon(
                              onPressed: () {},
                              label: Text(
                                'Create An Account',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 18,
                                ),
                              ),
                              icon: Icon(Icons.key),

                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.black,
                                iconColor: Colors.white,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),

                  // End Sign Button
                ],
              ),
            ),

            // End 2nd Container
          ],
        ),
      ),
    );
  }
}
