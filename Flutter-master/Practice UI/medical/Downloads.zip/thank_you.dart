import 'package:flutter/material.dart';
import 'package:material_symbols_icons/material_symbols_icons.dart';
import 'package:google_fonts/google_fonts.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,

      title: 'Thank You',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue),
        textTheme: GoogleFonts.josefinSansTextTheme(),
      ),
      home: const MyHomePage(title: 'Thank You 😊'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.blue.shade300,
        title: Text('Recent Purchase'),
        centerTitle: true,
      ),
      drawer: Drawer(
        child: ListView(
          children: [
            Container(
              height: 90,
              width: double.infinity,
              child: Align(
                alignment: Alignment.center,
                child: DrawerHeader(
                  curve: Curves.bounceIn,
                  child: SizedBox(
                    child: Image.network(
                      'https://tinyurl.com/3j9befdn',
                      fit: BoxFit.contain,
                    ),
                  ),
                ),
              ),
            ),
            SizedBox(height: 30),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                TextButton.icon(
                  onPressed: () {},
                  label: Text('Home'),
                  icon: Icon(Icons.home),
                ),
                TextButton.icon(
                  onPressed: () {},
                  label: Text('Product'),
                  icon: Icon(Icons.local_pharmacy),
                ),
                TextButton.icon(
                  onPressed: () {},
                  label: Text('Checkout'),
                  icon: Icon(Icons.shopping_bag),
                ),
              ],
            ),

            Row(
              children: [
                TextButton.icon(
                  onPressed: () {},
                  label: Text('Sign In'),
                  icon: Icon(Icons.add_home),
                ),
                TextButton.icon(
                  onPressed: () {},
                  label: Text('Create An Account'),
                  icon: Icon(Icons.person),
                ),
              ],
            ),
          ],
        ),
      ),

      body: Container(
        width: double.infinity,
        height: double.infinity,
        child: Center(
          child: Container(
            width: MediaQuery.sizeOf(context).width * 0.96,
            height: MediaQuery.sizeOf(context).height * 0.4,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20),
            ),
            child: Padding(
              padding: EdgeInsets.all(12),
              child: Column(
                children: [
                  Image.asset(
                    'assets/icons/thanks.gif',
                    width: 120,
                    height: 120,
                  ),
                  Text(
                    'Thanks for Shopping with us 😊',
                    style: GoogleFonts.josefinSans(
                      fontSize: 21,
                      fontWeight: FontWeight.w700,
                    ),
                    textAlign: TextAlign.center,
                  ),

                  SizedBox(height: 09),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      ElevatedButton.icon(
                        onPressed: () {},
                        label: Text(
                          'Track your Order!',
                          style: TextStyle(
                            fontWeight: FontWeight.w700,
                            fontSize: 12,
                          ),
                        ),
                        icon: Icon(Symbols.order_approve),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.blue.shade50,
                          foregroundColor: Colors.black,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(06),
                          ),
                        ),
                      ),

                      ElevatedButton.icon(
                        onPressed: () {},
                        label: Text(
                          'Shop More',
                          style: TextStyle(
                            fontWeight: FontWeight.w700,
                            fontSize: 12,
                          ),
                        ),
                        icon: Icon(Symbols.order_approve),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.blue,
                          foregroundColor: Colors.white,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(06),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
