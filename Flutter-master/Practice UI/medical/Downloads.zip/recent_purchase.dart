import 'package:flutter/material.dart';
import 'package:material_symbols_icons/material_symbols_icons.dart';
import 'package:google_fonts/google_fonts.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Purchase History',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue),
        textTheme: GoogleFonts.josefinSansTextTheme(),
      ),
      home: const MyHomePage(title: 'Purchase History'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.blue.shade300,
        title: Text('Recent Purchase'),
        centerTitle: true,
      ),
      drawer: Drawer(
        child: ListView(
          children: [
            Container(
              height: 90,
              width: double.infinity,
              child: Align(
                alignment: Alignment.center,
                child: DrawerHeader(
                  curve: Curves.bounceIn,
                  child: SizedBox(
                    child: Image.network(
                      'https://tinyurl.com/3j9befdn',
                      fit: BoxFit.contain,
                    ),
                  ),
                ),
              ),
            ),
            SizedBox(height: 30),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                TextButton.icon(
                  onPressed: () {},
                  label: Text('Home'),
                  icon: Icon(Icons.home),
                ),
                TextButton.icon(
                  onPressed: () {},
                  label: Text('Product'),
                  icon: Icon(Icons.local_pharmacy),
                ),
                TextButton.icon(
                  onPressed: () {},
                  label: Text('Checkout'),
                  icon: Icon(Icons.shopping_bag),
                ),
              ],
            ),

            Row(
              children: [
                TextButton.icon(
                  onPressed: () {},
                  label: Text('Sign In'),
                  icon: Icon(Icons.add_home),
                ),
                TextButton.icon(
                  onPressed: () {},
                  label: Text('Create An Account'),
                  icon: Icon(Icons.person),
                ),
              ],
            ),
          ],
        ),
      ),

      body: Container(
        color: Colors.white10,
        child: ListView.builder(
          itemCount: 9,
          itemBuilder: (context, index) {
            return Container(
              margin: EdgeInsets.all(09),

              width: MediaQuery.sizeOf(context).width * 1,
              height: MediaQuery.sizeOf(context).height * 0.2,
              decoration: BoxDecoration(
                color: Colors.blue.shade100,
                borderRadius: BorderRadius.circular(12),
                boxShadow: [
                  BoxShadow(
                    color: Colors.blue.shade200,
                    spreadRadius: 01,
                    blurRadius: 2,
                    offset: Offset(00, 03),
                  ),
                ],
              ),

              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,

                children: [
                  // left hand
                  Padding(
                    padding: EdgeInsets.only(right: 6),
                    child: ClipRRect(
                      borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(15),
                        bottomLeft: Radius.circular(15),
                      ),
                      child: Container(
                        width: MediaQuery.of(context).size.width * 0.43,
                        height: MediaQuery.of(context).size.height * 0.35,
                        decoration: BoxDecoration(
                          image: DecorationImage(
                            image: NetworkImage('https://tinyurl.com/3z2u6ahh'),
                            fit: BoxFit.cover,
                          ),
                        ),
                      ),
                    ),
                  ),

                  // End left hand

                  // Description tab
                  Container(
                    width: MediaQuery.sizeOf(context).width * 0.5,
                    height: MediaQuery.sizeOf(context).height * 0.3,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          'Prescription drugs on an orange background with...',
                          style: TextStyle(
                            fontSize: 15,
                            fontWeight: FontWeight.w500,
                          ),
                        ),

                        Container(
                          width: MediaQuery.sizeOf(context).width * 0.9,
                          margin: EdgeInsets.all(0),

                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              // Delivery Details on the left
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    'Delivered on Monday',
                                    style: TextStyle(
                                      fontSize: 12,
                                      color: Colors.blueGrey,
                                    ),
                                  ),
                                  SizedBox(height: 06),
                                  Row(
                                    children: [
                                      IconButton(
                                        onPressed: () {},
                                        style: IconButton.styleFrom(
                                          backgroundColor: Colors.blue.shade200,
                                          shape: RoundedRectangleBorder(
                                            borderRadius: BorderRadius.circular(
                                              10,
                                            ),
                                          ),
                                        ),
                                        icon: Icon(
                                          Symbols.download,
                                          color: Colors.blue,
                                        ),
                                      ),

                                      IconButton(
                                        onPressed: () {},
                                        style: IconButton.styleFrom(
                                          backgroundColor: Colors.blue.shade200,
                                          shape: RoundedRectangleBorder(
                                            borderRadius: BorderRadius.circular(
                                              10,
                                            ),
                                          ),
                                        ),
                                        icon: Icon(
                                          Symbols.share,
                                          color: Colors.blue,
                                        ),
                                      ),

                                      IconButton(
                                        onPressed: () {},
                                        style: IconButton.styleFrom(
                                          backgroundColor: Colors.blue.shade200,
                                          shape: RoundedRectangleBorder(
                                            borderRadius: BorderRadius.circular(
                                              10,
                                            ),
                                          ),
                                        ),
                                        icon: Icon(
                                          Symbols.delete,
                                          color: Colors.blue,
                                        ),
                                      ),

                                      IconButton(
                                        onPressed: () {},
                                        style: IconButton.styleFrom(
                                          backgroundColor: Colors.blue.shade200,
                                          shape: RoundedRectangleBorder(
                                            borderRadius: BorderRadius.circular(
                                              10,
                                            ),
                                          ),
                                        ),
                                        icon: Icon(
                                          Symbols.more_vert,
                                          color: Colors.blue,
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),

                              // Price on the right
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),

                  // End Description Tab
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}
