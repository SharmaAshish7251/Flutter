import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,

      title: 'Product Screen',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue),
     textTheme: GoogleFonts.josefinSansTextTheme(),
      ),
      home: const MyHomePage(title: 'Product Screen'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: Drawer(
        child: IconButton(onPressed: () {}, icon: Icon(Icons.menu)),
      ),
      bottomNavigationBar: Container(
        height: MediaQuery.sizeOf(context).height * 0.15,
        child: Container(
          color: const Color.fromARGB(167, 186, 237, 250),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              Column(
                children: [
                  Container(
                    margin: EdgeInsets.only(left: 06, right: 06, bottom: 06),
                    width: MediaQuery.sizeOf(context).width * 0.9,
                    height: MediaQuery.sizeOf(context).height * 0.09,

                    child: ElevatedButton.icon(
                      onPressed: () {},

                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.blue,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(30),
                        ),
                      ),
                      icon: Icon(
                        Icons.shopping_cart,
                        size: 23,
                        color: Colors.white,
                      ),

                      label: Text(
                        'Add to cart',
                        style: TextStyle(fontSize: 21, color: Colors.white),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),

      body: SingleChildScrollView(
        child: Container(
          child: Expanded(
            child: Column(
              children: [
                // Product Tab

                // Feature Image
                Row(
                  children: [
                    ClipRRect(
                      borderRadius: BorderRadius.only(
                        bottomRight: Radius.circular(15),
                        bottomLeft: Radius.circular(15),
                      ),
                      child: Container(
                        height: MediaQuery.sizeOf(context).height * 0.4,
                        width: MediaQuery.sizeOf(context).width * 1,
                        decoration: BoxDecoration(
                          image: DecorationImage(
                            image: NetworkImage('https://tinyurl.com/3z2u6ahh'),
                            fit: BoxFit.cover,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
                // End Feature Image

                // Start Description
                Padding(
                  padding: EdgeInsets.all(12),
                  child: Container(
                    width: double.infinity,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // Start Title
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              'Paracetamol Pill Bottle ',
                              style: TextStyle(
                                fontSize: 21,
                                fontWeight: FontWeight.w900,
                              ),
                              textAlign: TextAlign.left,
                            ),
                            ElevatedButton(
                              onPressed: () {},
                              child: Text(
                                '₹ 990',
                                style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.w900,
                                ),
                              ),
                            ),
                          ],
                        ), // End Title

                        Divider(height: 3, color: Colors.blue),
                        SizedBox(height: 13),
                        Row(children: [

  ],
),

                        Text(
                          'Paracetamol Tablets are a widely used pain reliever and fever reducer. Each tablet contains 500 mg of Paracetamol, an analgesic and antipyretic agent that helps relieve mild to moderate pain such as headaches, toothaches, muscle aches, backaches, menstrual cramps, and reduces fever caused by infections.',
                          style: TextStyle(fontSize: 16),
                        ),
                        SizedBox(height: 6),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Dosage Strength:',
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            Text('500 mg (commonly used; adjust if needed)'),
                          ],
                        ),
                        SizedBox(height: 6),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Key Features:',
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            Text(
                              '1. Effective relief from mild to moderate pain and fever',
                            ),
                            Text('2. Easy-to-swallow tablets'),
                            Text('3. Safe and hygienic packaging'),
                            Text(
                              '4. Tamper-evident seal for product integrity',
                            ),
                          ],
                        ),

                        // End Key features
                        SizedBox(height: 9),

                        // Directions for Use:
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Directions for Use:',
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            Text(
                              'Adults and children over 12 years: 1–2 tablets every 4–6 hours as needed. Do not exceed 8 tablets in 24 hours.',
                            ),
                            SizedBox(height: 3),
                            Text(
                              'Children (6–12 years): ½ to 1 tablet every 4–6 hours as needed. Do not exceed 4 tablets in 24 hours.',
                            ),
                          ],
                        ),

                        // End Directions for Use
                        SizedBox(height: 10),

                        // Storage Instructions:
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Storage Instructions:',
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                              ),
                            ),

                            Text(
                              'Store in a cool, dry place below 25°C. Keep out of reach of children.',
                            ),
                          ],
                        ),

                        // End Storage Instructions
                        SizedBox(height: 10),
                      ],
                    ),
                  ),
                ),
                // End Description

                // End Product Tab
              ],
            ),
          ),
        ),
      ),
    );
  }
}
