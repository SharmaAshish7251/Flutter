import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,

      title: 'Home Screen',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        textTheme: GoogleFonts.josefinSansTextTheme(),
      ),
      home: const MyHomePage(title: 'Medical Home Screen'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Container(
          width: MediaQuery.sizeOf(context).width * 0.99,

          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              CircleAvatar(
                backgroundImage: NetworkImage('https://tinyurl.com/msnbn5jp'),
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Delivery address',
                    style: TextStyle(
                      color: Colors.blueGrey,
                      fontSize: 15,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Text(
                    'XX Dwarka, New Delhi 1100XX',
                    style: TextStyle(
                      color: Colors.black,
                      fontWeight: FontWeight.bold,
                      fontSize: 18,
                    ),
                  ),
                ],
              ),

              CircleAvatar(
                backgroundImage: NetworkImage('https://tinyurl.com/3xyjf8c4'),
                child: Icon(Icons.shopping_bag),
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: Container(
        child: Container(
          color: Colors.grey.shade300,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              Icon(Icons.home, size: 32, color: Colors.lightBlue),
              Icon(Icons.medical_services, size: 32, color: Colors.blueGrey),
              Icon(Icons.search, size: 32, color: Colors.blueGrey),
              Icon(Icons.shopping_cart, size: 32, color: Colors.blueGrey),
              Icon(
                Icons.supervised_user_circle_outlined,
                size: 32,
                color: Colors.blueGrey,
              ),
            ],
          ),
        ),
      ),

      body: Container(
        child: Column(
          children: [
            SizedBox(height: 10),
            // Search Bar
            Center(
              child: Container(
                width: MediaQuery.sizeOf(context).width * 0.9,

                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Expanded(
                      child: TextField(
                        decoration: InputDecoration(
                          label: Text('Search'),
                          prefixIcon: Icon(Icons.search),
                          fillColor: Colors.blue,
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12),
                            borderSide: BorderSide(width: 2),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),

            // End Search Bar

            // Category
            Container(
              margin: EdgeInsets.all(09),
              height: 45,
              width: MediaQuery.sizeOf(context).width * 0.9,
              child: ListView(
                scrollDirection: Axis.horizontal,
                children: [
                  Container(
                    decoration: BoxDecoration(
                      color: Color.fromARGB(45, 115, 202, 245),
                      border: Border.all(width: 2, color: Colors.lightBlue),
                      borderRadius: BorderRadius.circular(30),
                    ),
                    child: TextButton.icon(
                      onPressed: () {},
                      label: Text(
                        'Medicines',
                        style: TextStyle(color: Colors.lightBlueAccent),
                      ),
                      icon: Icon(
                        Icons.medication_outlined,
                        color: Colors.lightBlueAccent,
                      ),
                    ),
                  ),

                  SizedBox(width: 09),
                  Container(
                    decoration: BoxDecoration(
                      border: Border.all(width: 2, color: Colors.blueGrey),
                      borderRadius: BorderRadius.circular(30),
                    ),
                    child: TextButton.icon(
                      onPressed: () {},
                      label: Text(
                        'Medicines',
                        style: TextStyle(color: Colors.blueGrey),
                      ),
                      icon: Icon(
                        Icons.medication_outlined,
                        color: Colors.blueGrey,
                      ),
                    ),
                  ),

                  SizedBox(width: 09),
                  Container(
                    decoration: BoxDecoration(
                      border: Border.all(width: 2, color: Colors.blueGrey),
                      borderRadius: BorderRadius.circular(30),
                    ),
                    child: TextButton.icon(
                      onPressed: () {},
                      label: Text(
                        'Labtes',
                        style: TextStyle(color: Colors.blueGrey),
                      ),
                      icon: Icon(Icons.local_hospital, color: Colors.blueGrey),
                    ),
                  ),

                  SizedBox(width: 09),
                  Container(
                    decoration: BoxDecoration(
                      border: Border.all(width: 2, color: Colors.blueGrey),
                      borderRadius: BorderRadius.circular(30),
                    ),
                    child: TextButton.icon(
                      onPressed: () {},
                      label: Text(
                        'Checkup',
                        style: TextStyle(color: Colors.blueGrey),
                      ),
                      icon: Icon(Icons.local_hospital, color: Colors.blueGrey),
                    ),
                  ),
                ],
              ),
            ),
            //End Category

            // Slider
            Container(
              width: MediaQuery.sizeOf(context).width * 0.89,
              height: MediaQuery.sizeOf(context).height * 0.30,
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: NetworkImage('https://tinyurl.com/bdd2yjv2'),
                  fit: BoxFit.cover,
                ),
                borderRadius: BorderRadius.circular(12),
              ),
            ),

            // End Slider

            // Product Tab
            Expanded(
              child: ListView(
                scrollDirection: Axis.vertical,
                children: [
                  Container(
                    margin: EdgeInsets.all(09),

                    width: MediaQuery.sizeOf(context).width * 0.7,
                    height: MediaQuery.sizeOf(context).height * 0.2,
                    decoration: BoxDecoration(
                      color: const Color.fromARGB(17, 96, 125, 139),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,

                      children: [
                        // left hand
                        Padding(
                          padding: EdgeInsets.only(right: 06),
                          child: Container(
                            width: MediaQuery.sizeOf(context).width * 0.4,
                            height: MediaQuery.sizeOf(context).height * 0.45,
                            decoration: BoxDecoration(
                              image: DecorationImage(
                                image: NetworkImage(
                                  'https://tinyurl.com/3z2u6ahh',
                                ),
                              ),
                            ),
                          ),
                        ),
                        // End left hand

                        // Description tab
                        Container(
                          width: MediaQuery.sizeOf(context).width * 0.5,
                          height: MediaQuery.sizeOf(context).height * 0.3,
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                'Prescription drugs on an orange background with a pill bottle. Orange pills.',
                                style: TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),

                              Container(
                                child: Row(
                                  children: [
                                    Icon(
                                      Icons.star,
                                      color: Colors.yellow,
                                      size: 12,
                                    ),
                                    Icon(
                                      Icons.star,
                                      color: Colors.yellow,
                                      size: 12,
                                    ),
                                    Icon(
                                      Icons.star,
                                      color: Colors.yellow,
                                      size: 12,
                                    ),
                                    Icon(
                                      Icons.star,
                                      color: Colors.yellow,
                                      size: 12,
                                    ),
                                    Icon(
                                      Icons.star_outline,
                                      color: Colors.blueGrey,
                                      size: 12,
                                    ),
                                  ],
                                ),
                              ),

                              Container(
                                child: Row(
                                  children: [
                                    ElevatedButton.icon(
                                      onPressed: () {},
                                      label: Text('Add to cart'),
                                      icon: Icon(Icons.shopping_bag),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),

                        // End Description Tab
                      ],
                    ),
                  ),

                  // 2nd Card
                  Container(
                    margin: EdgeInsets.all(09),

                    width: MediaQuery.sizeOf(context).width * 0.9,
                    height: MediaQuery.sizeOf(context).height * 0.2,
                    decoration: BoxDecoration(
                      color: const Color.fromARGB(17, 96, 125, 139),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,

                      children: [
                        // left hand
                        Padding(
                          padding: EdgeInsets.only(right: 06),
                          child: Container(
                            width: MediaQuery.sizeOf(context).width * 0.4,
                            height: MediaQuery.sizeOf(context).height * 0.45,
                            decoration: BoxDecoration(
                              image: DecorationImage(
                                image: NetworkImage(
                                  'https://tinyurl.com/3z2u6ahh',
                                ),
                              ),
                            ),
                          ),
                        ),
                        // End left hand

                        // Description tab
                        Container(
                          width: MediaQuery.sizeOf(context).width * 0.5,
                          height: MediaQuery.sizeOf(context).height * 0.3,
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                'Prescription drugs on an orange background with a pill bottle. Orange pills.',
                                style: TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),

                              Container(
                                child: Row(
                                  children: [
                                    Icon(
                                      Icons.star,
                                      color: Colors.yellow,
                                      size: 12,
                                    ),
                                    Icon(
                                      Icons.star,
                                      color: Colors.yellow,
                                      size: 12,
                                    ),
                                    Icon(
                                      Icons.star,
                                      color: Colors.yellow,
                                      size: 12,
                                    ),
                                    Icon(
                                      Icons.star,
                                      color: Colors.yellow,
                                      size: 12,
                                    ),
                                    Icon(
                                      Icons.star_outline,
                                      color: Colors.blueGrey,
                                      size: 12,
                                    ),
                                  ],
                                ),
                              ),

                              Container(
                                child: Row(
                                  children: [
                                    ElevatedButton.icon(
                                      onPressed: () {},
                                      label: Text('Add to cart'),
                                      icon: Icon(Icons.shopping_bag),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),

                        // End Description Tab
                      ],
                    ),
                  ),

                  // End 2nd Card
                ],
              ),
            ),
            // End Product Tab
          ],
        ),
      ),
    );
    // This trailing comma makes auto-formatting nicer for build methods.
  }
}
