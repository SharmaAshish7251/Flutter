import 'package:flutter/material.dart';
import 'package:medical_ui/checkout_screen.dart';
import 'package:medical_ui/home_screen.dart';
import 'package:medical_ui/product_screen.dart';

class ShopScreen extends StatefulWidget {
  const ShopScreen({super.key});

  @override
  State<ShopScreen> createState() => _ShopScreenState();
}

class _ShopScreenState extends State<ShopScreen> {
  @override
  Widget build(BuildContext context) {
    final List<String> items = List.generate(
      20,
      (index) => "Paracetamol Pill Bottle ${index + 1}",
    );

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.blue.shade300,
        title: Text('Garuda Shop'),
        centerTitle: true,
      ),
      drawer: Drawer(
        child: ListView(
          children: [
            Container(
              height: 90,
              width: double.infinity,
              child: Align(
                alignment: Alignment.center,
                child: DrawerHeader(
                  curve: Curves.bounceIn,
                  child: SizedBox(
                    child: Image.network(
                      'https://tinyurl.com/3j9befdn',
                      fit: BoxFit.contain,
                    ),
                  ),
                ),
              ),
            ),
            SizedBox(height: 30),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                TextButton.icon(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => HomeScreen()),
                    );
                  },
                  label: Text('Home'),
                  icon: Icon(Icons.home),
                ),
                TextButton.icon(
                  onPressed: () {},
                  label: Text('Product'),
                  icon: Icon(Icons.local_pharmacy),
                ),
                TextButton.icon(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => CheckoutScreen()),
                    );
                  },
                  label: Text('Checkout'),
                  icon: Icon(Icons.shopping_bag),
                ),
              ],
            ),

            Row(
              children: [
                TextButton.icon(
                  onPressed: () {},
                  label: Text('Sign In'),
                  icon: Icon(Icons.add_home),
                ),
                TextButton.icon(
                  onPressed: () {},
                  label: Text('Create An Account'),
                  icon: Icon(Icons.person),
                ),
              ],
            ),
          ],
        ),
      ),

      body: GridView.builder(
        padding: const EdgeInsets.all(10),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          crossAxisSpacing: 10,
          mainAxisSpacing: 10,
          childAspectRatio: 1.2,
        ),
        itemCount: items.length,
        itemBuilder: (context, index) {
          return InkWell(
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => ProductScreen()),
              );
            },
            child: Card(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              elevation: 4,
              child: Container(
                padding: const EdgeInsets.all(8),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(12),
                      child: Image.network(
                        'https://tinyurl.com/3z2u6ahh',
                        height: 100,
                        width: double.infinity,
                        fit: BoxFit.cover,
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      items[index],
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Expanded(
                      child: Text(
                        'Paracetamol Tablets are a widely used pain reliever and fever reducer. Each tablet contains 500 mg of paracetamol.',
                        style: const TextStyle(fontSize: 12),
                        maxLines: 3,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
