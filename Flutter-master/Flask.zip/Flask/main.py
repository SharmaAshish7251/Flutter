from flask import Flask, request, jsonify 
from createTable import create_table 
import sqlite3
from addOperation import createUser
from authUser import auth_user
from readOperation import get_all_user_read
from singleUser import fetch_single_user
# from deleteUser import user_delete_db


app = Flask(__name__)  #Create a Flask application


#route
@app.route('/', methods=['GET'])
def home_route():
    return 'Hello Dev'




@app.route('/createUser', methods=['POST'])
def create_user():
    try : 
        name = request.form['name']
        password = request.form['password']
        email = request.form['email']
        address = request.form['address']
        phone_number = request.form['phone_number']
                
        pin_code = request.form['pin_code']

        user_uuid = createUser(name=name, password=password, email=email, phone_number=phone_number,address=address, pin_code=pin_code)

        return jsonify({'message' :  user_uuid, 'status' : 200})


    except Exception as error:
        return jsonify({'message': str(error), 'status': 400})


@app.route('/login', methods=['POST'])
def login():
    try : 
        email = request.form['email']
        password = request.form['password']

        user = auth_user(email=email, password=password)
        if user:
            return jsonify({'status': 200, 'message' : user[1]})
        else:
            return jsonify({'status': 401, 'message': 'Invaild Credentials'})

    

    except Exception as error: 
        return jsonify({'status': 400, 'message': str(error)})



@app.route('/getAllUsers', methods=['GET'])
def get_all_user():
    try : 


        users = get_all_user_read()


        if users:
            return jsonify({'status': 200, 'message' : users})
        else: 
            return jsonify({'status' : 404, 'message' : 'No Users Found'})
        



    except Exception as error:
        return jsonify({'status': 400, 'message': str(error)})    



@app.route('/getSingleUser', methods=['POST'])
def get_single_user():
    try :
      
        user_id = request.form['user_id'] # pass user id to user , request.form is flask function
        single_user  = fetch_single_user(user_id)

        if single_user: 
            return jsonify({'status' : 200, 'message': single_user})
        else : 
            return jsonify({'status' : 404, 'message' : 'No User found'})
       


    except Exception as error:
        return jsonify({'status' : 403, 'message' : str(error)})


# @app.route('/deleteUser', methods=['DELETE'])
# def delete_user():
#     try :

       
#         user_id = request.form['user_id']


#         conn = sqlite3.connect('my_medicalShopV2.db')
#         cursor = conn.cursor()

#         cursor.execute('DELETE FROM Users WHERE user_id = ?',  (user_id))

#         conn.commit()
#         conn.close()

#         return jsonify({'status': 200, 'message' : 'User Deleted Sucessfully'})

#     except Exception as error:
#         return jsonify({'status' : 403, 'message' : str(error)})



if __name__=='__main__':
   
    create_table()   # to run table query, all queries execute after main

    app.run(debug=True) 